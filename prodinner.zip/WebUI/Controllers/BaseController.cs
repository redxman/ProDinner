﻿using System.Web.Mvc;

namespace Omu.ProDinner.WebUI.Controllers
{
    public class BaseController : Controller
    {
    }
}